package controlador;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBConnect {
    public Connection connect(){
        Connection con = null;
        try{
            String url = "jdbc:mysql://localhost:3306/vinylDB";
            String user = "root";
            String pass = "akerek98";
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conectado exitosamente!");           
        }catch(Exception ex){System.out.println(ex.getMessage());}
        return con;
    }
}
