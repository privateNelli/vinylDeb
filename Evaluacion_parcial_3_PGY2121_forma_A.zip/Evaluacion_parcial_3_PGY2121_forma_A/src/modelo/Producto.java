package modelo;

/**
 *
 * @author Kili
 */
public class Producto {
    
}
